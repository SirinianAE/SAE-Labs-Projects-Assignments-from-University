//Author: Sirinian Aram Emmanouil AM: 2537

#include <stdio.h>
#include <omp.h>

#define UPTO 10000000

long int count;		/* number of primes */
long int lastprime;	/* the last prime found */

void openmp_primes(long int n);

int main()
{
	double t1, t2, elapse;
	int i;
	
	t1 = omp_get_wtime();
	openmp_primes(UPTO);
	t2 = omp_get_wtime();
	elapse = t2 - t1;
	printf("count = %ld, last = %ld (time = %f)\n", count, lastprime, elapse);
	
	return 0;
}

void openmp_primes(long int n){
	long int i, num, divisor, quotient, remainder;
	
	if (n < 2) return;
	count = 1;
	lastprime = 2;
	omp_set_dynamic(0);
	omp_set_num_threads(4);
	#pragma opm parallel firstprivate(i) private(num, divisor, quotient, remainder) shared(count, lastprime)
	#pragma opm single
	{
		for (i = 0; i < (n-1)/2; ++i) {
			#pragma omp task private(quotient) firstprivate(num) shared(remainder, divisor)
			{
				num = 2*i + 3;
				divisor = 1;
				
				do
				{
					divisor += 2;
					quotient  = num / divisor;  
					remainder = num % divisor;  
				} while (remainder && divisor <= quotient);
				
				if (remainder || divisor == num)
				{
					count++;
					lastprime = num;
				}
			}
		}
	}
}
