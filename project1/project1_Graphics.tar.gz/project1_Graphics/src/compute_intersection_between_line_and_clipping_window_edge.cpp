/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void compute_intersection_between_line_and_clipping_window_edge(int x1, int y1, int x2, int y2, int edge_position, int* x, int* y){
	float slope = (float) (y2 - y1)/(x2 - x1);
	if(edge_position == RIGHT_EDGE){
		*x = clippingWindowMaxX;
		*y = (slope*(clippingWindowMaxX - x1)) + y1;
	}
	if(edge_position == TOP_EDGE){
		*x = x1 + ((clippingWindowMaxY - y1)/slope);
		*y = clippingWindowMaxY;
	}
	if(edge_position == LEFT_EDGE){
		*x = clippingWindowMinX;
		*y = (slope*(clippingWindowMinX - x1)) + y1;
	}
	if(edge_position == BOTTOM_EDGE){
		*x = x1 + ((clippingWindowMinY - y1)/slope);
		*y = clippingWindowMinY;
	}
}
