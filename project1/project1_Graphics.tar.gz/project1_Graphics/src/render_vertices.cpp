/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void render_vertices(void){
	struct polygon_s *current_polygon = firstPolygon;
	glPushMatrix();
	if(current_polygon != NULL){
		float r = black_color[0];
		float g = black_color[1];
		float b = black_color[2];
		glColor3f(r, g, b);
	}
	while(current_polygon != NULL){
		if(not current_polygon->complete){
			struct vertex_s *current_vertice = current_polygon->firstVertices;
			if(current_vertice != NULL){
				while(current_vertice != NULL){
					int x = current_vertice->x;
					int y = current_vertice->y;

					glBegin(GL_POINTS);
					glVertex2i(x, y);
					glEnd();
					current_vertice = current_vertice->next;
				}
			}
		}
		current_polygon = current_polygon->next;
	}
	glPopMatrix();
}
