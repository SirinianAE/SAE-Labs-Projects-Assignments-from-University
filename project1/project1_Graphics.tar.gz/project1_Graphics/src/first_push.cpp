/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void first_push(int x1, int y1, int x2, int y2, int x3, int y3){
	head = (struct triangle_s *) malloc(sizeof(struct triangle_s));
	if(head == NULL){
		exit(-1);
	}
	head->x1 = x1;
	head->y1 = y1;
	head->x2 = x2;
	head->y2 = y2;
	head->x3 = x3;
	head->y3 = y3;
	head->next = NULL;
}
