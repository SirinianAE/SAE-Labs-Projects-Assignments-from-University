/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void mouse_motion(int x, int y){
	if(menuOption == CLIPPING){
		clippingWindowCornerToX = x;
		clippingWindowCornerToY = SCREEN_HEIGHT - y;
	}
}
