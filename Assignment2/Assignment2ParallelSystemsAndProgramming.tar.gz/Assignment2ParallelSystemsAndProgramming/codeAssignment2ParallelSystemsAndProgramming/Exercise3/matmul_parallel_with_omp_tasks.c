//Author: Sirinian Aram Emmanouil, AM: 2537

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#define N 1024
#define _mat(i,j) (mat[(i)*n + (j)])

int S;
int M;
int NTASK;
int taskid = 0;
int A[N][N], B[N][N], C[N][N];

int readmat(char *fname, int *mat, int n);
int writemat(char *fname, int *mat, int n);
void parallel_function();
void taskexecute(int wid);
void check_command_line_arguments(int argc, char *argv);


int main(int argc, char *argv[]){
	int i;
	double t1, t2, elapse;
	
	check_command_line_arguments(argc, argv[1]);
	
	if (readmat("./Amat1024.txt", (int *) A, N) < 0){
		printf("reading file problem.\n");
		exit(1);
	}
	if (readmat("./Bmat1024.txt", (int *) B, N) < 0){
		printf("reading file problem.\n");
		exit(1);
	}
	
	t1 = omp_get_wtime();
	parallel_function();
	t2 = omp_get_wtime();
	elapse = t2 - t1;
	
	if (writemat("./Cmat1024.txt", (int *) C, N) < 0){
		exit( 1 + printf("writing file problem\n") );
	}
	printf("Time: %f\n", elapse);
	return 0;
}

void check_command_line_arguments(int argc, char *argv){
	if (argc == 2){
		;
	}else if (argc > 2){
		printf("Too many arguments supplied.\n");
		exit(1);
	}else{
		printf("One argument expected.\n");
		exit(1);
	}
	
	float tempS = atof(argv);
	float tempM = (float) N/tempS;
	
	if ((tempS == 0) || (roundf(tempS) != tempS) ||
	 (roundf(tempM) != tempM)){
		printf("argument problem.\n");
		exit(1);
	}
	
	S = (int) tempS;
	M = (int) tempM;
	NTASK = M*M;
}

void parallel_function(){
	int t;
	
	omp_set_dynamic(0);
	omp_set_num_threads(4);
	#pragma opm parallel shared(taskid, NTASK) private(t)
	#pragma opm single
	{
		while(1){
			t = taskid++;
			if (t >= NTASK){
				break;
			}
			#pragma omp task shared(A, B, C, S, M) firstprivate(t)
			{
				taskexecute(t);
			}
		}
	}
}

void taskexecute(int wid){
	int i, j, k, x, y;
	double sum;
	
	x = wid / M;
	y = wid % M;
	for (i = x*S; i < (x+1)*S; i++){
		for (j = y*S; j < (y+1)*S; j++){
			for (k = 0, sum = 0.0; k < N; k++){
				sum += A[i][k]*B[k][j];
			}
			C[i][j] = sum;
		}
	}
}


int readmat(char *fname, int *mat, int n){
	FILE *fp;
	int  i, j;
	
	if ((fp = fopen(fname, "r")) == NULL)
		return (-1);
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
			if (fscanf(fp, "%d", &_mat(i,j)) == EOF)
			{
				fclose(fp);
				return (-1); 
			};
	fclose(fp);
	return (0);
}


int writemat(char *fname, int *mat, int n){
	FILE *fp;
	int  i, j;
	
	if ((fp = fopen(fname, "w")) == NULL)
		return (-1);
	for (i = 0; i < n; i++, fprintf(fp, "\n"))
		for (j = 0; j < n; j++)
			fprintf(fp, " %d", _mat(i, j));
	fclose(fp);
	return (0);
}
