/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void mouse_button(int button, int state, int x, int y){
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN){
		if(menuOption == POLYGON){
			add_vertices(firstPolygon, x, SCREEN_HEIGHT - y);
			menuOption = POLYGON;
		}
		if(menuOption == CLIPPING){
			clippingWindowCornerFromX = x;
			clippingWindowCornerFromY = SCREEN_HEIGHT - y;
		}
	}else if(button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN){
		if(menuOption == POLYGON){
			add_polygon(&firstPolygon);
		}
		if(menuOption == CLIPPING){
			menuOption = NOTHING_SELECTED;
			compute_Xmax_Ymax_Xmin_Ymin();
			clipping_sutherland_hodgman();
		}
	}
}
