/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void process_action_menu(int option){
	switch(option){
		case POLYGON:
			add_polygon(&firstPolygon);
			menuOption = POLYGON;
			break;
		case CLIPPING:
			menuOption = CLIPPING;
			break;
		case EXIT:
			menuOption = EXIT;
			free_triangle_list(head);
			free_polygon_list(firstPolygon);
			free_polygon_list(currentClippedPolygon);
			exit(0);
			break;
	}
}
