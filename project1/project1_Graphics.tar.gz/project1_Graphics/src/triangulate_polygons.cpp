/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>
#include <triangulate.h>

void triangulate_polygons(void){
	if(renderTriangles and (not isTriangulationOfPolygonsNeeded)){
		struct polygon_s *current_polygon = firstPolygon;

		free_triangle_list(head);
		head = NULL;

		while(current_polygon != NULL){
			Vector2dVector a;
			struct vertex_s *current_vertice = current_polygon->firstVertices;
			if(current_vertice != NULL){
				while(current_vertice != NULL){
					int x = current_vertice->x;
					int y = current_vertice->y;

					a.push_back( Vector2d(x, y));
					current_vertice = current_vertice->next;
				}
				Vector2dVector result;
				Triangulate::Process(a,result);
				int tcount = result.size()/3;
				for (int i=0; i<tcount; i++){
					const Vector2d &p1 = result[i*3+0];
					const Vector2d &p2 = result[i*3+1];
					const Vector2d &p3 = result[i*3+2];
					push(p1.GetX(), p1.GetY(), p2.GetX(), p2.GetY(), p3.GetX(), p3.GetY());
				}
			}
			current_polygon = current_polygon->next;
		}

		isTriangulationOfPolygonsNeeded = true;
	}
}
