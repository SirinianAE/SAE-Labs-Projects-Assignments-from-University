/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void render_polygon(void){
	struct polygon_s *current_polygon = firstPolygon;
	glPushMatrix();
	while(current_polygon != NULL){
		if(current_polygon != NULL){
			float r = current_polygon->polygon_fill_color[0];
			float g = current_polygon->polygon_fill_color[1];
			float b = current_polygon->polygon_fill_color[2];
			glColor3f(r, g, b);
		}
		if(current_polygon->complete){
			glBegin(GL_POLYGON);
			struct vertex_s *currentVertice = current_polygon->firstVertices;
			if(currentVertice != NULL){
				while(currentVertice != NULL){
					int x = currentVertice->x;
					int y = currentVertice->y;

					glVertex2i(x, y);
					currentVertice = currentVertice->next;
				}
			}
			glEnd();
		}
		current_polygon = current_polygon->next;
	}
	glPopMatrix();
}
