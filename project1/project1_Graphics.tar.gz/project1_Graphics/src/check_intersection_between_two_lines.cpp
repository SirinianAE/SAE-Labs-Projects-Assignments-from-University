/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>
#include <math.h>

bool check_intersection_between_two_lines(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4){
	int x12 = x1 - x2;
	int y12 = y1 - y2;
	int x34 = x3 - x4;
	int y34 = y3 - y4;
	int c = ((x12 * y34) - (y12 * x34));
	int a;
	int b;
	float x;
	float y;


	if(fabs(c) <= 0.01){
		return false;
	}else{
		a = x1 * y2 - y1 * x2;
		b = x3 * y4 - y3 * x4;
		x = (float) (a * x34 - b * x12) / c;
		y = (float) (a * y34 - b * y12) / c;
		if((fmin(x1, x2)<=x and x<=fmax(x1, x2) and fmin(x3, x4)<=x and x<=fmax(x3, x4)) and (fmin(y1, y2)<=y and y<=fmax(y1, y2) and fmin(y3, y4)<=y and y<=fmax(y3, y4))){
			return true;
		}
	}
	return false;
}
