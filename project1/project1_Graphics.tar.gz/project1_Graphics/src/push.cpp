/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void push(int x1, int y1, int x2, int y2, int x3, int y3){
	if(head == NULL){
		first_push(x1, y1, x2, y2, x3, y3);
		return;
	}

	struct triangle_s *current = head;
	while(current->next != NULL){
		current = current->next;
	}

	current->next = (struct triangle_s *) malloc(sizeof(struct triangle_s));
	current->next->x1 = x1;
	current->next->y1 = y1;
	current->next->x2 = x2;
	current->next->y2 = y2;
	current->next->x3 = x3;
	current->next->y3 = y3;
	current->next->next = NULL;
}
