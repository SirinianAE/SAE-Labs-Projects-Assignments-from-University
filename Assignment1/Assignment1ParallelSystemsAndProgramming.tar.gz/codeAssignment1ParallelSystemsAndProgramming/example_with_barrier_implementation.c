//Author: Sirinian Aram Emmanouil, AM: 2537
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#define BARRIER_FLAG 200000000
#define NUMBER_OF_CONSECUTIVE_BARRIER_WAITS 1000
#define NUMBER_OF_THREADS 16
#define NUMBER_OF_POINTLESS_LOOPS 2000000000

typedef struct barrier_s barrier_t;

struct barrier_s {
	unsigned number_of_threads;
	unsigned number_of_waiting_threads;
	pthread_mutex_t m;
	pthread_cond_t cv;
};

barrier_t bar;
void *thread_function(void *arg);
void barrier_init(barrier_t *b, unsigned n);
int barrier_wait(barrier_t *b);
void barrier_destroy(barrier_t *b);

void barrier_init(barrier_t *b, unsigned n){
	pthread_mutex_init(&b->m, NULL);
	pthread_cond_init(&b->cv, NULL);
	b->number_of_threads = n;
	b->number_of_waiting_threads = BARRIER_FLAG;
}

int barrier_wait(barrier_t *b){
	pthread_mutex_lock(&b->m);
	while (b->number_of_waiting_threads > BARRIER_FLAG){
		pthread_cond_wait(&b->cv, &b->m);
	}
	if (b->number_of_waiting_threads == BARRIER_FLAG){
		b->number_of_waiting_threads = 0;
	}
	b->number_of_waiting_threads++;
	if (b->number_of_waiting_threads == b->number_of_threads){
		b->number_of_waiting_threads += BARRIER_FLAG - 1;
		pthread_cond_broadcast(&b->cv);
		pthread_mutex_unlock(&b->m);
		return PTHREAD_BARRIER_SERIAL_THREAD;
	}else{
		while (b->number_of_waiting_threads < BARRIER_FLAG){
			pthread_cond_wait(&b->cv, &b->m);
		}
		b->number_of_waiting_threads--;
		if (b->number_of_waiting_threads == BARRIER_FLAG){
			pthread_cond_broadcast(&b->cv);
		}
		pthread_mutex_unlock(&b->m);
		return 0;
	}
}

void barrier_destroy(barrier_t *b){
	pthread_mutex_lock(&b->m);
	while (b->number_of_waiting_threads > BARRIER_FLAG){
		pthread_cond_wait(&b->cv, &b->m);
	}
	pthread_mutex_unlock(&b->m);
	
	pthread_cond_destroy(&b->cv);
	pthread_mutex_destroy(&b->m);
}

int main(){
	int i;
	pthread_t thrid[NUMBER_OF_THREADS];
	struct timeval tv1, tv2;
	double t;
	long number_of_pointless_iterations_for_each_loop = 
		NUMBER_OF_POINTLESS_LOOPS / NUMBER_OF_THREADS;
	
	barrier_init(&bar, NUMBER_OF_THREADS);
	gettimeofday(&tv1, NULL);
	for (i = 0; i < NUMBER_OF_THREADS; i++){
		pthread_create(&thrid[i], NULL, thread_function,
		 (void *) number_of_pointless_iterations_for_each_loop);
	}
	for (i = 0; i < NUMBER_OF_THREADS; i++){
		pthread_join(thrid[i], NULL);
	}
	gettimeofday(&tv2, NULL);
	barrier_destroy(&bar);
	
	t = (tv2.tv_sec - tv1.tv_sec) + (tv2.tv_usec - tv1.tv_usec)*1.0E-6;
	printf("real time: %lf sec.\n", t);
	return 0;
}

void *thread_function(void *arg){
	int i;
	long loops = (long) arg;
	unsigned useless_varaible = 0;
	
	for (i=0; i < loops; i++){
		useless_varaible++;
		useless_varaible = 0;
	}
	
	for (i=0; i<NUMBER_OF_CONSECUTIVE_BARRIER_WAITS; i++){
		barrier_wait(&bar);
	}
}
