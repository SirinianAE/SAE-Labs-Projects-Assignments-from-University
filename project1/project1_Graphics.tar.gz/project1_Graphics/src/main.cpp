/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

struct polygon_s *firstPolygon = NULL;
struct polygon_s *currentClippedPolygon = NULL;
struct triangle_s *head = NULL;

int menuOption = NOTHING_SELECTED;

bool renderTriangles = false;
bool isTriangulationOfPolygonsNeeded= false;

int mainMenu, actionMenu, lineColorMenu, fillColorMenu;

int clippingWindowCornerFromY = 0;
int clippingWindowCornerFromX = 0;
int clippingWindowCornerToY = 0;
int clippingWindowCornerToX = 0;
int clippingWindowMaxX = 0;
int clippingWindowMaxY = 0;
int clippingWindowMinX = 0;
int clippingWindowMinY = 0;

int main(int argc,char** argv)
{
	glutInit(&argc,argv);
	glutInitWindowSize(SCREEN_WIDTH,SCREEN_HEIGHT);
	glutInitWindowPosition(0,0);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutCreateWindow("Project 1");
	glutKeyboardFunc(process_normal_keys);
	glutMouseFunc(mouse_button);
	glutMotionFunc(mouse_motion);
	glutDisplayFunc(display);
	glutIdleFunc(display);
	create_popup_menus();
	glutMainLoop();
}
