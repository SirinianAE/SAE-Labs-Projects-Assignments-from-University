/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void render_triangles_frame(void){
	struct triangle_s *current_triangle = head;
	glPushMatrix();
	glEnable(GL_POLYGON_OFFSET_LINE);
	glPolygonOffset(-1,-1);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	if(current_triangle != NULL){
		float r = green_color[0];
		float g = green_color[1];
		float b = green_color[2];
		glColor3f(r, g, b);
	}
	while(current_triangle != NULL){
		glBegin(GL_POLYGON);
		glVertex2i(current_triangle->x1, current_triangle->y1);
		glVertex2i(current_triangle->x2, current_triangle->y2);
		glVertex2i(current_triangle->x3, current_triangle->y3);
		glEnd();
		current_triangle = current_triangle->next;
	}
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glDisable(GL_POLYGON_OFFSET_LINE);
	glPopMatrix();
}
