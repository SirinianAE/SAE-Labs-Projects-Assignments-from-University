/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>
#include <math.h>

void compute_Xmax_Ymax_Xmin_Ymin(void){
	clippingWindowMaxX = fmax(clippingWindowCornerFromX, clippingWindowCornerToX);
	clippingWindowMinX = fmin(clippingWindowCornerFromX, clippingWindowCornerToX);
	clippingWindowMaxY = fmax(clippingWindowCornerFromY, clippingWindowCornerToY);
	clippingWindowMinY = fmin(clippingWindowCornerFromY, clippingWindowCornerToY);
}
