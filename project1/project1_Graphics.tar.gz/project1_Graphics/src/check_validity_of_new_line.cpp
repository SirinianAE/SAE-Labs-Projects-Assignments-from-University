/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

bool check_validity_of_new_line(struct polygon_s *first){
	int x1;
	int y1;
	int x2;
	int y2;
	int x3;
	int y3;
	int x4;
	int y4;
	struct vertex_s *first_vertice_of_first_line;
	struct vertex_s *second_vertice_of_first_line;
	struct vertex_s *first_vertice_of_current_line;
	struct vertex_s *second_vertice_of_current_line;
	int intersection_point_X;
	int intersection_point_Y;
	bool neighbor_lines = true;

	if(first != NULL){

		if(first->firstVertices == NULL){
			return true;
		}else if(first->firstVertices->next == NULL){
			return true;
		}else if(first->firstVertices->next->next == NULL){
			return true;
		}

		first_vertice_of_first_line = first->firstVertices;
		second_vertice_of_first_line = first->firstVertices->next;
		first_vertice_of_current_line = first->firstVertices->next;
		second_vertice_of_current_line = first->firstVertices->next->next;

		x1 = first_vertice_of_first_line->x;
		y1 = first_vertice_of_first_line->y;
		x2 = second_vertice_of_first_line->x;
		y2 = second_vertice_of_first_line->y;

		while(true){

			x3 = first_vertice_of_current_line->x;
			y3 = first_vertice_of_current_line->y;
			x4 = second_vertice_of_current_line->x;
			y4 = second_vertice_of_current_line->y;

			if(check_intersection_between_two_lines(x1, y1, x2, y2, x3, y3, x4, y4)){
				compute_intersection_between_two_lines(x1, y1, x2, y2, x3, y3, x4, y4, &intersection_point_X, &intersection_point_Y);
				if(not(neighbor_lines and intersection_point_X == x2 and intersection_point_Y == y2)){
					return false;
				}
			}

			if(second_vertice_of_current_line->next == NULL){
				return true;
			}

			first_vertice_of_current_line = first_vertice_of_current_line->next;
			second_vertice_of_current_line = second_vertice_of_current_line->next;
			neighbor_lines = false;

		}
	}

	return true;

}
