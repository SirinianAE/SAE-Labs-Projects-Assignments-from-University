/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void free_vertex_list(struct vertex_s *currentVertex){
	struct vertex_s *tmp_vertex;

	while(currentVertex != NULL){
		tmp_vertex = currentVertex;
		currentVertex = currentVertex->next;
		free(tmp_vertex);
	}
}
