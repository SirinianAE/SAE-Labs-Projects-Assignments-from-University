/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

bool check_if_vertex_inside(int x, int y, int clip_edge){
	switch(clip_edge){
		case RIGHT_EDGE:
			if(x<clippingWindowMaxX){
				return true;
			}else{
				return false;
			}
			break;
		case TOP_EDGE:
			if(y<clippingWindowMaxY){
				return true;
			}else{
				return false;
			}
			break;
		case LEFT_EDGE:
			if(x>clippingWindowMinX){
				return true;
			}else{
				return false;
			}
			break;
		case BOTTOM_EDGE:
			if(y>clippingWindowMinY){
				return true;
			}else{
				return false;
			}
			break;
		default:
			return false;
			break;
	}
}
