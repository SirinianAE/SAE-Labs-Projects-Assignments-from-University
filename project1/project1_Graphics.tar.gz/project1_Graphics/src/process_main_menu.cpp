/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void process_main_menu(int option){

}
