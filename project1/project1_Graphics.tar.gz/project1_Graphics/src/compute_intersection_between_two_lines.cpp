/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>
#include <math.h>

void compute_intersection_between_two_lines(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int* x, int* y){
	int x12 = x1 - x2;
	int y12 = y1 - y2;
	int x34 = x3 - x4;
	int y34 = y3 - y4;
	int c = ((x12 * y34) - (y12 * x34));
	int a = x1 * y2 - y1 * x2;
	int b = x3 * y4 - y3 * x4;
	*x = (a * x34 - b * x12) / c;
	*y = (a * y34 - b * y12) / c;
}
