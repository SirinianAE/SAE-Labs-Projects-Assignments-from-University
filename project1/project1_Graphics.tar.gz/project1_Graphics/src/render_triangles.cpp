/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void render_triangles(void){
	struct triangle_s *current_triangle = head;
	glPushMatrix();
	if(current_triangle != NULL){
		float r = red_color[0];
		float g = red_color[1];
		float b = red_color[2];
		glColor3f(r, g, b);
	}
	while(current_triangle != NULL){
		glBegin(GL_TRIANGLES);
		glVertex2i(current_triangle->x1, current_triangle->y1);
		glVertex2i(current_triangle->x2, current_triangle->y2);
		glVertex2i(current_triangle->x3, current_triangle->y3);
		glEnd();
		current_triangle = current_triangle->next;
	}
	glPopMatrix();
}
