/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>

#define SCREEN_WIDTH 600
#define SCREEN_HEIGHT 500

#define NOTHING_SELECTED 0
#define POLYGON 1
#define EXIT 2
#define CLIPPING 3
#define RENDER_TRIANGLES 4

#define BLACK_COLOR 1
#define WHITE_COLOR 2
#define RED_COLOR 3
#define GREEN_COLOR 4
#define BLUE_COLOR 5
#define YELLOW_COLOR 6
#define CYAN_COLOR 7
#define MAGENTA_COLOR 8
#define GREY_COLOR 9
#define BROWN_COLOR 10
#define KHAKI_COLOR 11
#define NAVY_COLOR 12
#define ORANGE_COLOR 13
#define PINK_COLOR 14
#define PLUM_COLOR 15
#define VIOLET_COLOR 16

#define RIGHT_EDGE 1
#define TOP_EDGE 2
#define LEFT_EDGE 3
#define BOTTOM_EDGE 4

struct vertex_s{
	int x;
	int y;
	struct vertex_s *next;
};

struct polygon_s{
	struct vertex_s *firstVertices;
	struct polygon_s *next;
	float polygon_fill_color[3];
	float polygon_line_color[3];
	bool complete;
};

struct triangle_s{
	int x1;
	int y1;
	int x2;
	int y2;
	int x3;
	int y3;
	struct triangle_s *next;
};

void create_popup_menus(void);
void display(void);
void process_main_menu(int);
void render_line_strip(void);
void render_polygon(void);
void render_polygon_frame(void);
void render_vertices(void);
void process_action_menu(int);
void add_vertices(struct polygon_s*, int, int);
void add_polygon(struct polygon_s**);
void mouse_button(int, int, int, int);
void first_push(int, int, int, int, int, int);
void push(int, int, int, int, int, int);
void triangulate_polygons(void);
void process_normal_keys(unsigned char, int, int);
void render_triangles(void);
void render_triangles_frame(void);
bool check_intersection_between_two_lines(int, int, int, int, int, int, int, int);
bool check_validity_of_new_line(struct polygon_s*);
void compute_intersection_between_two_lines(int, int, int, int, int, int, int, int, int*, int*);
void process_fill_color_menu(int);
void process_line_color_menu(int);
void change_color(const float*, float*);
void mouse_motion(int, int);
void render_clipping_window(void);
bool check_if_vertex_inside(int, int, int);
void compute_Xmax_Ymax_Xmin_Ymin(void);
void clipping_sutherland_hodgman(void);
void compute_intersection_between_line_and_clipping_window_edge(int, int, int, int, int, int*, int*);
void free_triangle_list(struct triangle_s*);
void free_vertex_list(struct vertex_s*);
void free_polygon_list(struct polygon_s*);

extern int mainMenu;
extern int actionMenu;
extern int lineColorMenu;
extern int fillColorMenu;

extern struct polygon_s *firstPolygon;
extern struct polygon_s *currentClippedPolygon;
extern struct triangle_s *head;

extern int menuOption;

extern bool renderTriangles;
extern bool isTriangulationOfPolygonsNeeded;

extern int clippingWindowCornerFromY;
extern int clippingWindowCornerFromX;
extern int clippingWindowCornerToY;
extern int clippingWindowCornerToX;
extern int clippingWindowMaxX;
extern int clippingWindowMinX;
extern int clippingWindowMaxY;
extern int clippingWindowMinY;

const float black_color[] = { 0, 0, 0 };
const float white_color[] = { 1, 1, 1 };
const float red_color[] = { 1, 0, 0 };
const float green_color[] = { 0, 1, 0 };
const float blue_color[] = { 0, 0, 1 };
const float yellow_color[] = { 1, 1, 0 };
const float cyan_color[] = { 0, 1, 1 };
const float magenta_color[] = { 1, 0, 1 };
const float grey_color[] = { 0.752941, 0.752941, 0.752941 };
const float brown_color[] = { 0.647059, 0.164706, 0.164706 };
const float khaki_color[] = { 0.623529, 0.623529, 0.372549 };
const float navy_color[] = { 0.137255, 0.137255, 0.556863 };
const float orange_color[] = { 1, 0.5, 0 };
const float pink_color[] = { 0.737255, 0.560784, 0.560784 };
const float plum_color[] = { 0.917647, 0.678431, 0.917647 };
const float violet_color[] = { 0.309804, 0.184314, 0.309804 };
