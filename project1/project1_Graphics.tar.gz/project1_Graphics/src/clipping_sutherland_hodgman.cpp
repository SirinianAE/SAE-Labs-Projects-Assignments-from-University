/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void clipping_sutherland_hodgman(void){
	int edge_position;
	for(int i = 0; i < 4; i++){
		struct polygon_s *current_polygon = firstPolygon;
		struct polygon_s **first_clipped_polygon = &currentClippedPolygon;
		if(i == 0){
			edge_position = RIGHT_EDGE;
		}
		if(i == 1){
			edge_position = TOP_EDGE;
		}
		if(i == 2){
			edge_position = LEFT_EDGE;
		}
		if(i == 3){
			edge_position = BOTTOM_EDGE;
		}


		while(current_polygon != NULL){
			bool is_vertex_A_inside;
			bool is_vertex_B_inside;

			add_polygon(&currentClippedPolygon);
			currentClippedPolygon->polygon_fill_color[0] = current_polygon->polygon_fill_color[0];
			currentClippedPolygon->polygon_fill_color[1] = current_polygon->polygon_fill_color[1];
			currentClippedPolygon->polygon_fill_color[2] = current_polygon->polygon_fill_color[2];
			currentClippedPolygon->polygon_line_color[0] = current_polygon->polygon_line_color[0];
			currentClippedPolygon->polygon_line_color[1] = current_polygon->polygon_line_color[1];
			currentClippedPolygon->polygon_line_color[2] = current_polygon->polygon_line_color[2];

			if(current_polygon->firstVertices != NULL){
				struct vertex_s *vertexA = current_polygon->firstVertices;
				struct vertex_s *vertexB = current_polygon->firstVertices->next;
				int x1 = vertexA->x;
				int y1 = vertexA->y;
				while(vertexA != NULL){
					if(vertexB != NULL){
						int x1 = vertexA->x;
						int y1 = vertexA->y;
						int x2 = vertexB->x;
						int y2 = vertexB->y;
						int xp;
						int yp;
						compute_intersection_between_line_and_clipping_window_edge(x1, y1, x2, y2, edge_position, &xp, &yp);
						is_vertex_A_inside = check_if_vertex_inside(x1, y1, edge_position);
						is_vertex_B_inside = check_if_vertex_inside(x2, y2, edge_position);

						if((is_vertex_A_inside) and (is_vertex_B_inside)){
							add_vertices(currentClippedPolygon, x2, y2);
						}else if((is_vertex_A_inside) and (not is_vertex_B_inside)){
							add_vertices(currentClippedPolygon, xp, yp);
						}else if((not is_vertex_A_inside) and (not is_vertex_B_inside)){

						}else{
							add_vertices(currentClippedPolygon, xp, yp);
							add_vertices(currentClippedPolygon, x2, y2);
						}

						vertexB = vertexB->next;
					}
					vertexA = vertexA->next;
				}
				if(current_polygon->firstVertices != NULL and current_polygon->firstVertices->next != NULL){
					struct vertex_s *first = current_polygon->firstVertices;
					struct vertex_s *last = current_polygon->firstVertices->next;
					while(last->next != NULL){
						last = last->next;
					}
					int x1 = last->x;
					int y1 = last->y;
					int x2 = first->x;
					int y2 = first->y;
					int xp;
					int yp;
					compute_intersection_between_line_and_clipping_window_edge(x1, y1, x2, y2, edge_position, &xp, &yp);
					is_vertex_A_inside = check_if_vertex_inside(x1, y1, edge_position);
					is_vertex_B_inside = check_if_vertex_inside(x2, y2, edge_position);

					if((is_vertex_A_inside) and (is_vertex_B_inside)){
						add_vertices(currentClippedPolygon, x2, y2);
					}else if((is_vertex_A_inside) and (not is_vertex_B_inside)){
						add_vertices(currentClippedPolygon, xp, yp);
					}else if((not is_vertex_A_inside) and (not is_vertex_B_inside)){

					}else{
						add_vertices(currentClippedPolygon, xp, yp);
						add_vertices(currentClippedPolygon, x2, y2);
					}
				}
			}
			current_polygon = current_polygon->next;
		}

		free_polygon_list(firstPolygon);
		firstPolygon = NULL;
		while(*first_clipped_polygon != NULL){
			add_polygon(&firstPolygon);
			firstPolygon->polygon_fill_color[0] = (*first_clipped_polygon)->polygon_fill_color[0];
			firstPolygon->polygon_fill_color[1] = (*first_clipped_polygon)->polygon_fill_color[1];
			firstPolygon->polygon_fill_color[2] = (*first_clipped_polygon)->polygon_fill_color[2];
			firstPolygon->polygon_line_color[0] = (*first_clipped_polygon)->polygon_line_color[0];
			firstPolygon->polygon_line_color[1] = (*first_clipped_polygon)->polygon_line_color[1];
			firstPolygon->polygon_line_color[2] = (*first_clipped_polygon)->polygon_line_color[2];

			struct vertex_s *currentVertice = (*first_clipped_polygon)->firstVertices;
			while(currentVertice != NULL){
				int x = currentVertice->x;
				int y = currentVertice->y;
				add_vertices(firstPolygon, x, y);
				currentVertice = currentVertice->next;
			}
			*first_clipped_polygon = (*first_clipped_polygon)->next;
		}
		free_polygon_list(currentClippedPolygon);
		currentClippedPolygon = NULL;
	}
}
