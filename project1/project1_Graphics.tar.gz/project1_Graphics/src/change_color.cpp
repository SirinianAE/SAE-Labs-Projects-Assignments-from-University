/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void change_color(const float color[], float array[]){
	int i;
	for(i=0; i<3; i++){
		array[i] = color[i];
	}
}
