/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void free_triangle_list(struct triangle_s *currentTriangle){
	struct triangle_s *tmp_triangle;

	while(currentTriangle != NULL){
		tmp_triangle = currentTriangle;
		currentTriangle = currentTriangle->next;
		free(tmp_triangle);
	}
}
