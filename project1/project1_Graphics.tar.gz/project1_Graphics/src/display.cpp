/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void display(void){
	glClearColor(1, 1, 1, 0);
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(0,0,0);
	glPointSize(10);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, float(SCREEN_WIDTH), 0.0, float(SCREEN_HEIGHT));

	render_vertices();
	render_line_strip();
	render_polygon();
	render_polygon_frame();
	triangulate_polygons();
	if(renderTriangles){
		//render_triangles();
		render_triangles_frame();
	}
	if(menuOption == CLIPPING){
		render_clipping_window();
	}
	glFlush();
}
