/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void render_clipping_window(void){
	glPushMatrix();
	float r = green_color[0];
	float g = green_color[1];
	float b = green_color[2];
	glColor3f(r, g, b);
	glRecti(clippingWindowCornerFromX, clippingWindowCornerFromY, clippingWindowCornerToX, clippingWindowCornerToY);
	glPopMatrix();
}
