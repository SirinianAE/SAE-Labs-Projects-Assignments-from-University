/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void process_normal_keys(unsigned char key, int xx, int yy){
	if(key == 't' or key == 'T'){
		renderTriangles = not renderTriangles;
		isTriangulationOfPolygonsNeeded = false;
	}
}
