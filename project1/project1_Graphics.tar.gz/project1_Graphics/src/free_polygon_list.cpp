/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void free_polygon_list(struct polygon_s *currentPolygon){
	struct polygon_s *tmp_polygon;

	while(currentPolygon != NULL){
		struct vertex_s *tmpVertex = currentPolygon->firstVertices;
		free_vertex_list(tmpVertex);
		tmp_polygon = currentPolygon;
		currentPolygon = currentPolygon->next;
		free(tmp_polygon);
	}
}
