/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void add_polygon(struct polygon_s **first){
	struct polygon_s *newest = NULL;
	newest = (struct polygon_s *) malloc(sizeof(struct polygon_s));
	if(newest == NULL){
		printf("Out of memory! Exiting.\n");
		exit(1);
	}
	if(*first != NULL){
		(*first)->complete = true;
	}
	change_color(black_color, newest->polygon_line_color);
	change_color(white_color, newest->polygon_fill_color);
	newest->firstVertices = NULL;
	newest->next = *first;
	newest->complete = false;
	*first = newest;
}
