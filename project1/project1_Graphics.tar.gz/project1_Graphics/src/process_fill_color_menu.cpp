/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void process_fill_color_menu(int option){
	if(firstPolygon != NULL){
		switch(option){
			case BLACK_COLOR:
				change_color(black_color, firstPolygon->polygon_fill_color);
				break;
			case WHITE_COLOR:
				change_color(white_color, firstPolygon->polygon_fill_color);
				break;
			case RED_COLOR:
				change_color(red_color, firstPolygon->polygon_fill_color);
				break;
			case GREEN_COLOR:
				change_color(green_color, firstPolygon->polygon_fill_color);
				break;
			case BLUE_COLOR:
				change_color(blue_color, firstPolygon->polygon_fill_color);
				break;
			case YELLOW_COLOR:
				change_color(yellow_color, firstPolygon->polygon_fill_color);
				break;
			case CYAN_COLOR:
				change_color(cyan_color, firstPolygon->polygon_fill_color);
				break;
			case MAGENTA_COLOR:
				change_color(magenta_color, firstPolygon->polygon_fill_color);
				break;
			case GREY_COLOR:
				change_color(grey_color, firstPolygon->polygon_fill_color);
				break;
			case BROWN_COLOR:
				change_color(brown_color, firstPolygon->polygon_fill_color);
				break;
			case KHAKI_COLOR:
				change_color(khaki_color, firstPolygon->polygon_fill_color);
				break;
			case NAVY_COLOR:
				change_color(navy_color, firstPolygon->polygon_fill_color);
				break;
			case ORANGE_COLOR:
				change_color(orange_color, firstPolygon->polygon_fill_color);
				break;
			case PINK_COLOR:
				change_color(pink_color, firstPolygon->polygon_fill_color);
				break;
			case PLUM_COLOR:
				change_color(plum_color, firstPolygon->polygon_fill_color);
				break;
			case VIOLET_COLOR:
				change_color(violet_color, firstPolygon->polygon_fill_color);
				break;
		}
	}
}
