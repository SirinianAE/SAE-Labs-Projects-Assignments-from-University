/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void create_popup_menus(void){
	actionMenu = glutCreateMenu(process_action_menu);
	glutAddMenuEntry("POLYGON", POLYGON);
	glutAddMenuEntry("CLIPPING", CLIPPING);
	glutAddMenuEntry("EXIT", EXIT);

	lineColorMenu = glutCreateMenu(process_line_color_menu);
	glutAddMenuEntry("Black", BLACK_COLOR);
	glutAddMenuEntry("White", WHITE_COLOR);
	glutAddMenuEntry("Red", RED_COLOR);
	glutAddMenuEntry("Green", GREEN_COLOR);
	glutAddMenuEntry("Blue", BLUE_COLOR);
	glutAddMenuEntry("Yellow", YELLOW_COLOR);
	glutAddMenuEntry("Cyan", CYAN_COLOR);
	glutAddMenuEntry("Magenta", MAGENTA_COLOR);
	glutAddMenuEntry("Grey", GREY_COLOR);
	glutAddMenuEntry("Brown", BROWN_COLOR);
	glutAddMenuEntry("Khaki", KHAKI_COLOR);
	glutAddMenuEntry("Navy", NAVY_COLOR);
	glutAddMenuEntry("Orange", ORANGE_COLOR);
	glutAddMenuEntry("Pink", PINK_COLOR);
	glutAddMenuEntry("Plum", PLUM_COLOR);
	glutAddMenuEntry("Violet", VIOLET_COLOR);

	fillColorMenu = glutCreateMenu(process_fill_color_menu);
	glutAddMenuEntry("Black", BLACK_COLOR);
	glutAddMenuEntry("White", WHITE_COLOR);
	glutAddMenuEntry("Red", RED_COLOR);
	glutAddMenuEntry("Green", GREEN_COLOR);
	glutAddMenuEntry("Blue", BLUE_COLOR);
	glutAddMenuEntry("Yellow", YELLOW_COLOR);
	glutAddMenuEntry("Cyan", CYAN_COLOR);
	glutAddMenuEntry("Magenta", MAGENTA_COLOR);
	glutAddMenuEntry("Grey", GREY_COLOR);
	glutAddMenuEntry("Brown", BROWN_COLOR);
	glutAddMenuEntry("Khaki", KHAKI_COLOR);
	glutAddMenuEntry("Navy", NAVY_COLOR);
	glutAddMenuEntry("Orange", ORANGE_COLOR);
	glutAddMenuEntry("Pink", PINK_COLOR);
	glutAddMenuEntry("Plum", PLUM_COLOR);
	glutAddMenuEntry("Violet", VIOLET_COLOR);

	mainMenu = glutCreateMenu(process_main_menu);
	glutAddSubMenu("ACTION", actionMenu);
	glutAddSubMenu("LINE_COLOR", lineColorMenu);
	glutAddSubMenu("FILL_COLOR", fillColorMenu);

	glutAttachMenu(GLUT_RIGHT_BUTTON);
}
