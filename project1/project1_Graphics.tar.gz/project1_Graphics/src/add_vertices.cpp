/*
 * author:	Sirinian Aram Emmanouil
 * AM:		2537
 */
#include <project1.h>

void add_vertices(struct polygon_s *first, int x, int y){
	struct vertex_s *newest = NULL;
	newest = (struct vertex_s *) malloc(sizeof(struct vertex_s));
	if(newest == NULL){
		printf("Out of memory! Exiting.\n");
		exit(1);
	}
	newest->x = x;
	newest->y = y;
	newest->next = first->firstVertices;
	first->firstVertices = newest;

	if(not check_validity_of_new_line(first)){
		firstPolygon = firstPolygon->next;
		add_polygon(&firstPolygon);
	}

}
